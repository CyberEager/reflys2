<?php
/**
 *
 * @ EvolutionScript FULL DECODED & NULLED
 *
 * @ Version  : 5.1
 * @ Author   : GetAnyScript
 * @ Release on : 2014-12-28
 * @ Website  : http://www.getanyscript.com
 *
 **/

error_reporting(E_ALL & ~E_NOTICE);
define("LicenseNumber", "EvolutionScript Ultimate 5.1 BY GetAnyScript");
?>