<?php
/**
 *
 * @ EvolutionScript FULL DECODED & NULLED
 *
 * @ Version  : 5.1
 * @ Author   : GetAnyScript
 * @ Release on : 2014-12-28
 * @ Website  : http://www.getanyscript.com
 *
 **/

if (!defined("EvolutionScript")) {
	exit("Hacking attempt...");
}

$template = $cache->get("template");

if ($template == null) {
	$default_tpl = $db->fetchOne("SELECT COUNT(*) AS NUM FROM templates WHERE default_tpl=1 AND version='" . $software['version'] . "'");

	if ($default_tpl != 0) {
		$template = $db->fetchRow("SELECT * FROM templates WHERE default_tpl=1 AND version='" . $software['version'] . "'");
	}
	else {
		$template['name'] = "Modern Blue";
		$template['folder'] = "ModernBlue";
	}

	$cache->set("template", $template, 604800);
}

$templateFolder = $template['folder'];
$smarty = new Smarty();
$smarty->setTemplateDir(ROOTPATH . "templates/" . $templateFolder . "/");
$smarty->setCompileDir(ROOTPATH . "templates_c/" . $templateFolder . "/");
$smarty->config_dir = "configs/";
$smarty->setCacheDir(CACHE);
$smarty->assign("template_name", $templateFolder);
$smarty->assign("memberonly_support", MEMBERS_SUPPORT);
$smarty->assign("settings", $settings);

if ($settings['site_stats'] == "yes") {
	$smarty->assign("statistics", $statistics);
}


if ($settings['copyright'] != 0) {
	$smarty->assign("copyright", "<div style=\"margin-top:3px\">Powered by <a href=\"http://www.evolutionscript.com\">EvolutionScript</a> Version " . $software['version'] . "</div>");
}


if ($settings['allowchangelanguage'] == "yes") {
	$smarty->assign("language_list", $langlist);
	$smarty->assign("current_lang", $current_lang);
}

$smarty->assign("lang", $lang);

if ($_SESSION['logged']) {
	$unread_messages = $db->fetchOne("SELECT COUNT(*) AS NUM FROM messages WHERE user_to=" . $user_info['id'] . " AND user_read='no'");
	$smarty->assign("logged", $_SESSION['logged']);
	$smarty->assign("user_info", $user_info);
	$smarty->assign("unread_messages", $unread_messages);
}

$gatewaylist = $cache->get("gatewaylist");

if ($gatewaylist == null) {
	$q = $db->query("SELECT id FROM gateways WHERE status='Active'");

	while ($r = $db->fetch_array($q)) {
		$gatewaylist[] = $r['id'];
	}

	$cache->set("gatewaylist", $gatewaylist, 604800);
}


if (!is_array($gatewaylist)) {
	$gatewaylist = array();
}

$smarty->assign("gatewaylist", $gatewaylist);
?>