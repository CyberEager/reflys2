<?php
/**
 *
 * @ EvolutionScript 
 *
 * @ Version  : 5.1
 * @ Author   : GetAnyScript
 * @ Release on : 2014-12-28
 * @ Website  : http://www.getanyscript.com
 *
 **/

define("EvolutionScript", 1);
define("ROOTPATH", dirname(__FILE__) . "/");
define("INCLUDES", ROOTPATH . "includes/");
require_once INCLUDES . "global.php";
session_start();

if ($_REQUEST['m'] == "surfer") {
	$module = ROOTPATH . "modules/captcha/getcaptcha2.php";
	include $module;
	exit();
}

exit();
?>