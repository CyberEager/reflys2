<?php
/**
 *
 * @ EvolutionScript FULL DECODED & NULLED
 *
 * @ Version  : 5.1
 * @ Author   : GetAnyScript
 * @ Release on : 2014-12-28
 * @ Website  : http://www.getanyscript.com
 *
 **/

if (!defined("EvolutionScript")) {
	exit("Hacking attempt...");
}

echo "

</div>

	<div class=\"footer\">
    	<div  align=\"center\">Powered by EvolutionScript Version ";
echo $software['version'];
echo " Copyright &copy; 2010 - ";
echo date("Y");
echo " Getanyscript.com</div>

        <div class=\"clear\"></div>
	</div>
</div>


</body>
</html>
    ";
?>