<?php
/**
 *
 * @ EvolutionScript FULL DECODED & NULLED
 *
 * @ Version  : 5.1
 * @ Author   : GetAnyScript
 * @ Release on : 2014-12-28
 * @ Website  : http://www.getanyscript.com
 *
 **/

if (!defined("EvolutionScript")) {
	exit("Hacking attempt...");
}


if ($_SESSION['logged'] == "yes") {
	logout();
	header("location: index.php?view=logout");
	$db->close();
	exit();
}

require SMARTYLOADER;
$smarty->assign("logout_class", "current");
$smarty->assign("loginout_process", "logout");
$smarty->display("loginoutprocess.tpl");
$db->close();
exit();
?>