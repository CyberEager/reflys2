<?php
/**
 *
 * @ EvolutionScript FULL DECODED & NULLED
 *
 * @ Version  : 5.1
 * @ Author   : GetAnyScript
 * @ Release on : 2014-12-28
 * @ Website  : http://www.getanyscript.com
 *
 **/

if (!defined("EvolutionScript")) {
	exit("Hacking attempt...");
}

require SMARTYLOADER;
$smarty->assign("show_leftmenu", "no");
$smarty->assign("yesterday", strtotime("-1 day"));
$smarty->assign("user_group", $user_group);
$smarty->assign("uri", "forum.php?");
?>