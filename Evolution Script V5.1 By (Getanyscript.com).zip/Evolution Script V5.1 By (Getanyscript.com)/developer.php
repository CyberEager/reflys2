<?php
/**
 *
 * @ EvolutionScript 
 *
 * @ Version  : 5.1
 * @ Author   : GetAnyScript
 * @ Release on : 2014-12-28
 * @ Website  : http://www.getanyscript.com
 *
 **/

session_start();
define("EvolutionScript", 1);
require_once "./includes/init.php";
?>