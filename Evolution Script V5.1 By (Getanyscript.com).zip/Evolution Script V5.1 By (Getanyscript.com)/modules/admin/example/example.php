<?php
/**
 *
 * @ EvolutionScript FULL DECODED & NULLED
 *
 * @ Version  : 5.1
 * @ Author   : GetAnyScript
 * @ Release on : 2014-12-28
 * @ Website  : http://www.getanyscript.com
 *
 **/

if (!defined("EvolutionScript")) {
	exit("Hacking attempt...");
}

echo "
<p>This is an example module.  It's very simply to create your own and this file is an example.</p>

<p>You can run queries, calculate statistics or just display information which you need quick access to all from an addon module.</p>

<p>You can look at the code in \"<i>modules/admin/example/example.php</i>\" to see how it is constructed.</p>

<br /><br />";
?>