<?php
/**
 *
 * @ EvolutionScript FULL DECODED & NULLED
 *
 * @ Version  : 5.1
 * @ Author   : GetAnyScript
 * @ Release on : 2014-12-28
 * @ Website  : http://www.getanyscript.com
 *
 **/

if (!defined("EvolutionScript")) {
	exit("Hacking attempt...");
}

$credits = $db->fetchOne("SELECT days FROM loginads_price WHERE id=" . $order['item_id']);
addloginadcredits($order['user_id'], $credits);
?>