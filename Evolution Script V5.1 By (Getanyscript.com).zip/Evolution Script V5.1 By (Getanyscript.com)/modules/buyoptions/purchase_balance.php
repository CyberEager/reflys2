<?php
/**
 *
 * @ EvolutionScript FULL DECODED & NULLED
 *
 * @ Version  : 5.1
 * @ Author   : GetAnyScript
 * @ Release on : 2014-12-28
 * @ Website  : http://www.getanyscript.com
 *
 **/

if (!defined("EvolutionScript")) {
	exit("Hacking attempt...");
}

$productprice = $item * 2;
addpurchasebalance($user_info['id'], $productprice);
$db->query("UPDATE members SET money=money-" . $item . " WHERE id=" . $user_info['id']);
?>