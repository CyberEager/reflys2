<?php
/**
 *
 * @ EvolutionScript FULL DECODED & NULLED
 *
 * @ Version  : 5.1
 * @ Author   : GetAnyScript
 * @ Release on : 2014-12-28
 * @ Website  : http://www.getanyscript.com
 *
 **/

if (!defined("EvolutionScript")) {
	exit("Hacking attempt...");
}

$processor_form = "
<form action=\"https://perfectmoney.is/api/step1.asp\" method=\"POST\" id=\"checkout[id]\" >
<input type=\"hidden\" name=\"PAYEE_ACCOUNT\" value=\"[merchant]\">
<input type=\"hidden\" name=\"PAYEE_NAME\" value=\"[option1]\">
<input type=\"hidden\" name=\"PAYMENT_ID\" value=\"[userid]\">
<input type=\"hidden\" name=\"PAYMENT_AMOUNT\" id=\"amount[id]\" value=\"[price]\"/>
<input type=\"hidden\" name=\"PAYMENT_UNITS\" value=\"[currency]\"/>
<input type=\"hidden\" name=\"STATUS_URL\" value=\"[site_url]modules/gateways/pmstatus.php\">
<input type=\"hidden\" name=\"PAYMENT_URL\" value=\"[site_url]modules/gateways/thankyou2.php\">
<input type=\"hidden\" name=\"PAYMENT_URL_METHOD\" value=\"LINK\">
<input type=\"hidden\" name=\"NOPAYMENT_URL\" value=\"[site_url]modules/gateways/upgrade.php\"/>
<input type=\"hidden\" name=\"NOPAYMENT_URL_METHOD\" value=\"LINK\">
<input type=\"hidden\" name=\"SUGGESTED_MEMO\" value=\"[itemname]\">
<input type=\"hidden\" name=\"BAGGAGE_FIELDS\" value=\"upgrade\">
<input type=\"hidden\" name=\"upgrade\" value=\"\" id=\"upgrade[id]\">
</form>
";
?>